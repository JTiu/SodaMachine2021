﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SodaMachine
{
    class Quarter:Coin
    {
        //Member Variables (Has A)

        //Constructor (Spawner)
        public Quarter()
        {
            
        }

        //Member Methods (Can Do)
    }
}
