﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SodaMachine
{
    class OrangeSoda:Can
    {
        //Member Variables (Has A)

        //Constructor (Spawner)
        public OrangeSoda()
        {
            Name = "Orange Soda";
            price = 0.60;
        }

        //Member Methods (Can Do)
    }
}
