﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SodaMachine
{
    class Nickel:Coin
    {
        //Member Variables (Has A)

        //Constructor (Spawner)
        public Nickel()
        {
            
        }
        //Member Methods (Can Do)
    }
}
